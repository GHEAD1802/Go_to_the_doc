READ ME:

COMP3020 - GROUP 8:

To access the program, please find the file "Login.html" and launch it.

Because this is a prototype:

- Username and passwords can be anything.
- The input data such as card info, etc, can also be anything.
