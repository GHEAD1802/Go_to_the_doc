class Node {
  constructor (namey, spclt, time, cType, isPaid, prc1, prc2, gender) {
    this.namey = namey;
    this.spclt = spclt;
    this.time = time;
    this.cType = cType;
    this.isPaid = isPaid;
    this.prc1 = prc1;
    this.prc2 = prc2;
    this.taxous =(this.prc1*0.13+this.prc2*0.13);
    this.subto = this.prc1*1 + this.prc2*1 + this.taxous*1;
    this.gender = gender;
  }
}

var count = sessionStorage.getItem("count");
var index = sessionStorage.getItem("index"); // This is the cursor 

// This is the initial display.
var init = new Node ("NO APPOINTMENT IS MADE", "", "", "", -2, 0, 0, "none"); 

// This is the array of Doctors
var doctorsArray = [];
doctorsArray.push(init);

var curr = doctorsArray[0];

if (sessionStorage.getItem("appt_Time") != null) {
  var docName = sessionStorage.getItem("doctor_name");
  var spe = sessionStorage.getItem("speciality") + " Specialist"; 
  var tim = sessionStorage.getItem("appt_Time");
  var typ = sessionStorage.getItem("appt_Type");
  var gen = sessionStorage.getItem("doctor_gender");
  var mon = sessionStorage.getItem("charge1");
  addNewDoc(new Node(docName, spe, tim, typ, 0, mon, 10, gen));
}

// Use to add a new Doctor into the array.
function addNewDoc(newNode) {
  if (count == 0) {
    doctorsArray[0] = newNode;
    count++;
    change(doctorsArray[index]);
  } else {
    doctorsArray.push(newNode);
    count++;
  }
  
  sessionStorage.setItem("count", count);
  
  var theChart = document.getElementById("change_chart");
  var newOp = document.createElement("option");
  newOp.value = count-1;
  newOp.text = newNode.time;
  theChart.add(newOp);
}

function change(currNode) {
    document.getElementById("name").innerHTML = currNode.namey;
    document.getElementById("spclt").innerHTML = currNode.spclt;

document.getElementById("time").innerHTML = currNode.time;

document.getElementById("type").innerHTML = currNode.cType;

    if (currNode.cType === "Video Call") {
             document.getElementById("commu").src="img/video.jpg";
    } else if (currNode.cType === "Audio Call") {
        document.getElementById("commu").src="img/phone.jpg";
    } else if (currNode.cType === "Visit Clinic") {
      document.getElementById("commu").src="img/clinic.jpg";
    }
    
    if (currNode.isPaid == 0) {
        document.getElementById("paid").innerHTML = "CONFIRMATION REQUIRED";
    document.getElementById("paid").style.color = "red";
    document.getElementById("payb").style.display="block";
    } else if (currNode.isPaid != 0) {
         document.getElementById("paid").innerHTML = "ALREADY PAID";
    document.getElementById("paid").style.color = "green";
    document.getElementById("payb").style.display="none";
    }

  if (currNode.isPaid >= 0) {
    document.getElementById("price1").innerHTML = "$"+currNode.prc1;
    document.getElementById("price2").innerHTML = "$"+currNode.prc2;
    document.getElementById("tax").innerHTML = "$" + currNode.taxous;
    
    document.getElementById("total").innerHTML = "$"+currNode.subto;
  } else {
    document.getElementById("price1").innerHTML = "";
    document.getElementById("price2").innerHTML = "";
    document.getElementById("tax").innerHTML = "";
    
    document.getElementById("total").innerHTML = "";
  }

    if (currNode.isPaid == 0) {
        document.getElementById("total").style.color = "red";
    } else if (currNode.isPaid == 1) {
        document.getElementById("total").style.color = "green";
    } else {
      document.getElementById("total").innerHTML = "";
      document.getElementById("paid").innerHTML = "";
      
    }

    if (currNode.gender === "male") {
         document.getElementById("face").src = "img/avatar.jpg";
    } else if (currNode.gender === "female") {
        document.getElementById("face").src = "img/femaleAvt.jpg";
    } else {
      document.getElementById("face").src = "";
    }
}

function goBack() {
   if (index > 0) {
      index = index-1;
      curr = doctorsArray[index];
      change(curr);
   }
}

function goForth() {
    if (doctorsArray[index+1] !== undefined) {
      index = index+1;
      curr = doctorsArray[index]
      change(curr);
   }
}

function displayer() {
  var divi = document.getElementById("selection");
  if (divi.style.display === "none") {
    divi.style.display = "block";
  } else {
    divi.style.display = "none";
  }
}

var menu = document.getElementById("change_chart");
menu.addEventListener("change", changeData);

function changeData(event) {
  if (menu.value >= 0 && menu.value < count) {
    curr = doctorsArray[menu.value];
    index = menu.value;
    change(curr);
  }
}

function toPay() {
    document.getElementById("main").classList.toggle("payPage");

document.getElementById("paypay").style.display="block";
}

function success() {
    document.getElementById("paypay").style.display="none";
    document.getElementById("complete").style.display="block";

curr.isPaid = 1;
}

function backward() {
    document.getElementById("complete").style.display="none";
    document.getElementById("main").style.display="block";

change(curr);
}