class NodeT {
    constructor (date, time) {
        this.date = date;
        this.time = time;
    }
}

sessionStorage.setItem("count", 0);
sessionStorage.setItem("index", 0);

var countT = 0;
var indexT = 0; // This is the cursor 

// This is the initial display.

// This is the array of Time
var timeArray = [];

// Use to add a new Doctor into the array.
function addNewTime(newNodeT) {
    if (countT == 0) {
        timeArray[0] = newNodeT;
        countT++;
    } else {
        timeArray.push(newNodeT);
        countT++;
    }
    
    var theChart1 = document.getElementById("change_chart1");
    var newOp1 = document.createElement("option");
    newOp1.value = countT-1;
    newOp1.text = newNodeT.date +", " + newNodeT.time;
    theChart1.add(newOp1);
}

/////////////////
// DUMMY VALUE
////////////////

var time1 = new NodeT("Monday", "10:00 AM");
addNewTime(time1);

var time2 = new NodeT("Monday", "2:00 PM");
addNewTime(time2);

var time3 = new NodeT("Wednesday", "9:00 AM");
addNewTime(time3);

var time4 = new NodeT("Thursday", "9:00 AM");
addNewTime(time4);


var doc_name = sessionStorage.getItem("doctor_name");
var gender = sessionStorage.getItem("doctor_gender");
document.getElementById("doc_name").innerHTML = doc_name;

if(gender == "Male"){
    document.getElementById("avtr").src = "img/avatar.JPG"
}else{
    document.getElementById("avtr").src = "img/femaleAvt.JPG"
}

//Makes the select date and time disappear
var select_date = document.getElementById("dates");
var select_time = document.getElementById("slot");

select_date.className = "";
select_time.className = "";

//Changes to page 5
var button = document.getElementById("next_button");
button.onclick = function(){
    window.location.href = "infoForm.html";
}
var appointment_type = "";
var appointment_date = "";
var appointment_time = "";

function setType(x){
    if(x === 1){
        appointment_type = "Video Call";
    }
    if( x === 2){
        appointment_type = "Visit Clinic";
    }
    if(x === 3){
        appointment_type = "Audio Call";
    }
    if( x=== 4){
        appointment_type = "Other";
    }
    
    sessionStorage.setItem("appt_Type", appointment_type);

    //Makes the bottom selections appear/disappear
    if(select_date.className == "open"){
        select_date.className = "";
        select_time = "";
    }else{
        select_date.className = "open";
    }   
}

var menu = document.getElementById("change_chart1");
menu.addEventListener("change", changeData1);

function changeData1(event) {
    if (menu.value >= 0 && menu.value < countT) {
        appointment_time = timeArray[menu.value].date +", " + timeArray[menu.value].time;
        sessionStorage.removeItem("appt_Time");
        sessionStorage.setItem("appt_Time", appointment_time);
    }
}

function setDate(){
    
    //Makes the select time selection appear or disappear
    select_time.className = "open";
    
}

function setTime(){

    

}


