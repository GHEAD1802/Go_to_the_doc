var speciality = sessionStorage.getItem("speciality");
document.getElementById("doc_header").innerHTML = "Doctors specialised in "+speciality;

var doctor_name= "";
var doctor_age = "";
var doctor_gender = "";

function getDetails(x){
    if(x===1){
        doctor_name = "DR. Eren Yeager";
        doctor_age = 30;
        doctor_gender = "male";
    }
    if( x === 2){
        doctor_name = "DR. Lucy Heartfilia";
        doctor_age = 29;
        doctor_gender = "female";
    }
    if(x === 3){
        doctor_name = "DR. Stephen Strange";
        doctor_age = 45;
        doctor_gender = "male";
    }
    sessionStorage.setItem("doctor_name", doctor_name);
    sessionStorage.setItem("doctor_age",doctor_age);
    sessionStorage.setItem("doctor_gender", doctor_gender);
    window.location.href = "Treatment_page3.html";
}

