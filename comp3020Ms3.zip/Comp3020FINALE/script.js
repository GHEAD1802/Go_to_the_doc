class Node {
  constructor (namey, spclt, time, cType, isPaid, prc1, prc2, gender, next, prev) {
    this.namey = namey;
    this.spclt = spclt;
    this.time = time;
    this.cType = cType;
    this.isPaid = isPaid;
    this.prc1 = prc1;
    this.prc2 = prc2;
    this.taxous =(this.prc1+this.prc2)*0.13;
    this.subto = this.prc1 + this.prc2 + this.taxous;
    this.gender = gender;
    this.next = next;
    this.prev = prev;
  }
} 

var appt1 = new Node ("DR. MAREY JACSON", "Dentist", "Monday, 3:00 PM", "Video Call Visit", 0, 50, 20, "male", 0, 0); 

var appt2 = new Node ("DR. HELEN CATH", "Allergy Specialist", "Tuesday, 4:00 PM", "Meet at the clinic", 1, 60, 2, "female", 0, appt1);
appt1.next = appt2;


var appt3 = new Node ("DR. JAMES THESYS", "Digestive Specialist", "Thursday, 10:00  AM", "Audio Call Visit", 1, 60, 2, "male", 0, appt2);
appt2.next = appt3;

var curr = appt1;

function change(currNode) {
    document.getElementById("name").innerHTML = currNode.namey;
    document.getElementById("spclt").innerHTML = currNode.spclt;

document.getElementById("time").innerHTML = currNode.time;

document.getElementById("type").innerHTML = currNode.cType;

    if (currNode.cType === "Video Call Visit") {
             document.getElementById("commu").src="img/video.jpg";
    } else if (currNode.cType === "Audio Call Visit") {
        document.getElementById("commu").src="img/phone.jpg";
    } else {
      document.getElementById("commu").src="img/clinic.jpg";
    }
    
    if (currNode.isPaid == 0) {
        document.getElementById("paid").innerHTML = "CONFIRMATION REQUIRED";
    document.getElementById("paid").style.color = "red";
    document.getElementById("payb").style.display="block";
    } else {
         document.getElementById("paid").innerHTML = "ALREADY PAID";
    document.getElementById("paid").style.color = "green";
    document.getElementById("payb").style.display="none";
    }

    document.getElementById("price1").innerHTML = "$"+currNode.prc1;
    document.getElementById("price2").innerHTML = "$"+currNode.prc2;
    document.getElementById("tax").innerHTML = "$" + currNode.taxous;

    document.getElementById("total").innerHTML = "$"+currNode.subto;

    if (currNode.isPaid == 0) {
        document.getElementById("total").style.color = "red";
    } else if (currNode.isPaid == 1) {
        document.getElementById("total").style.color = "green";
    }

    if (currNode.gender === "male") {
         document.getElementById("face").src = "img/avatar.jpg";
    } else {
        document.getElementById("face").src = "img/femaleAvt.jpg";
    }
}

function goBack() {
   if (curr.prev != 0) {
      curr = curr.prev;
      change(curr);
   }
}

function goForth() {
    if (curr.next != 0) {
      curr = curr.next;
      change(curr);
   }
}

function displayer() {
  var divi = document.getElementById("selection");
  if (divi.style.display === "none") {
    divi.style.display = "block";
  } else {
    divi.style.display = "none";
  }
}

var menu = document.getElementById("change_chart");
menu.addEventListener("change", changeData);

function changeData(event) {
  if (menu.value == '1') {
    change(appt1);
  } else if (menu.value == '2') {
    change(appt2);
  } else if (menu.value == '3') {
    change(appt3);
  }
}

function toPay() {
    document.getElementById("main").classList.toggle("payPage");

document.getElementById("paypay").style.display="block";
}

function success() {
    document.getElementById("paypay").style.display="none";
    document.getElementById("complete").style.display="block";

curr.isPaid = 1;
}

function backward() {
    document.getElementById("complete").style.display="none";
    document.getElementById("main").style.display="block";

change(curr);
}