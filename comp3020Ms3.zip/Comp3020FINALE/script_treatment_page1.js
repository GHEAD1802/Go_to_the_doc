//Page 1 Start
var speciality = "";
function goToDocs(x){
    window.location.href = "Treatment_page2.html";
    if(x === 1){
        speciality = "Allergies";
    }
    if(x === 2){
        speciality = "Asthma";
    }
    if(x === 3){
        speciality = "Gastro";
    }
    sessionStorage.setItem("speciality", speciality);
}

var show_more_treatments = document.getElementById("cat_btn");
show_more_treatments.onclick = function(){
    if(show_more_treatments.innerHTML == "Show More"){
        document.getElementById("show_more").innerHTML = "Nohing else to show!";
        show_more_treatments.innerHTML = "Show Less";
    }
    else{
        document.getElementById("show_more").innerHTML = "";
        show_more_treatments.innerHTML = "Show More"
    }
}

var blog_content = document.getElementById("blog_txt");
var blog_button = document.getElementById("blog_bn");

blog_button.onclick = function(){
    if(blog_content.className == "open"){
        //shrink box
        
        blog_content.className = "";
        blog_button.innerHTML = "Show More";
    }
    else{
        //expand
        blog_content.className = "open";
        blog_button.innerHTML = "Show Less";
    }
}

// Page 1 END