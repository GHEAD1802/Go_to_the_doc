var gender = sessionStorage.getItem("doctor_gender");
var doctor_name = sessionStorage.getItem("doctor_name");
var doctor_age = sessionStorage.getItem("doctor_age");
var speciality = sessionStorage.getItem("speciality");
var charge = "";
var experience = "";

if(gender == "Male"){
    document.getElementById("avtr").src = "img/avatar.JPG"
}else{
    document.getElementById("avtr").src = "img/femaleAvt.JPG"
}

if(doctor_age > 30){
      experience = "20 years";
      charge = "$40 per visit";  
      chargeM = 40;
      sessionStorage.removeItem("charge1");
      sessionStorage.setItem("charge1", chargeM);
}
else if(doctor_age < 30){
    experience = "4 years";
    charge = "$20 per visit";
    chargeM = 20
    sessionStorage.removeItem("charge1");
    sessionStorage.setItem("charge1", chargeM);
}
else{
    experience = "5 years";
    charge = "$22 per visit";
    chargeM = 22;
    sessionStorage.removeItem("charge1");
    sessionStorage.setItem("charge1", chargeM);
}

document.getElementById("doc_name").innerHTML =  doctor_name;
document.getElementById("doc_speciality").innerHTML = speciality+" Specialist";
document.getElementById("charge").innerHTML += charge;
document.getElementById("experience").innerHTML += experience;

var button = document.getElementById("next_button");

button.onclick = function(){
    sessionStorage.setItem("charge",charge);
    sessionStorage.setItem("experience", experience);
    window.location.href = "Treatment_page4.html";
}