class Node {
  constructor (sympName, sympDesc, sympMedi, remedies, sympCause) {
    this.sympName = sympName;
    this.sympDesc = sympDesc;
    this.sympMedi = sympMedi;
    this.remedies = remedies;
    this.sympCause = sympCause;
  }
}

var count = 0;
var index = 0; // This is the cursor 

// This is the initial display.

// This is the array of Doctors
var sympArray = [];

var curr = sympArray[0];

// Use to add a new Doctor into the array.
function addNewSymp(newNode) {
  if (count == 0) {
    sympArray[0] = newNode;
    count++;
    change(sympArray[index]);
  } else {
    sympArray.push(newNode);
    count++;
  }
  var theChart = document.getElementById("change_chart");
  var newOp = document.createElement("option");
  newOp.value = count-1;
  newOp.text = newNode.sympName;
  theChart.add(newOp);
}

var sym1 = new Node ("HEADACHE", "Feeling a pain inside the head, frequently in the middle, or the frontal section of the head", "Paracetamol, 1 tablet per day. DO NOT TAKE MORE THAN 1 EVERY 6 HOURS", "Refrain from looking at the screen for a few hours, and also keep yourself warm at night.", "Looking at screen for an extended amount of time, or being cold at night when sleep"); 
addNewSymp(sym1);

var sym2 = new Node ("SORE THROAT", "Feeling a pain, or a rash inside the throat. You may feel irritated, and hard to swallow", "Strepsil, or any kind of throat clearing tablets.", "Refrain from drinking cold water, and also keep yourself warm at night.", "Being cold at night when sleep"); addNewSymp(sym2);

var sym3 = new Node ("EYE STRAIN", "Feeling an irritation inside the eye, and feeling jiggle when", "Eyes drop, 3 - 6 drops each time. Drop 1 time every 2 hours ", "Refrain from looking at the screen for a few hours, and also keep yourself warm at night.", "Looking at screen for an extended amount of time."); 
addNewSymp(sym3);

function change(currNode) {
    document.getElementById("name").innerHTML = currNode.sympName;
    document.getElementById("desc").innerHTML = currNode.sympDesc;
    document.getElementById("cause").innerHTML = currNode.sympCause;
    document.getElementById("med").innerHTML = currNode.sympMedi;
    document.getElementById("rem").innerHTML = currNode.remedies;
}

function goBack() {
   if (index > 0) {
      index = index-1;
      curr = sympArray[index];
      change(curr);
   }
}

function goForth() {
    if (sympArray[index+1] !== undefined) {
      index = index+1;
      curr = sympArray[index]
      change(curr);
   }
}

var menu = document.getElementById("change_chart");
menu.addEventListener("change", changeData);

function changeData(event) {
  if (menu.value >= 0 && menu.value < count) {
    curr = sympArray[menu.value];
    index = menu.value;
    change(curr);
  }
}

function displayer() {
  var divi = document.getElementById("selection");
  if (divi.style.display === "none") {
    divi.style.display = "block";
  } else {
    divi.style.display = "none";
  }
}
